<script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>
<script src="<?php echo base_url('assets/admin/'); ?>plugins/jquery-ui/jquery-ui.min.js"></script>
<script>
  $.widget.bridge('uibutton', $.ui.button)
</script>
<script src="<?php echo base_url('assets/admin/'); ?>plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo base_url('assets/admin/'); ?>plugins/chart.js/Chart.min.js"></script>
<!-- <script src="<?php echo base_url('assets/admin/'); ?>plugins/sparklines/sparkline.js"></script>
<script src="<?php echo base_url('assets/admin/'); ?>plugins/jqvmap/jquery.vmap.min.js"></script> -->
<!-- <script src="<?php echo base_url('assets/admin/'); ?>plugins/jqvmap/maps/jquery.vmap.usa.js"></script> -->
<script src="<?php echo base_url('assets/admin/'); ?>plugins/jquery-knob/jquery.knob.min.js"></script>
<script src="<?php echo base_url('assets/admin/'); ?>plugins/moment/moment.min.js"></script>
<script src="<?php echo base_url('assets/admin/'); ?>plugins/daterangepicker/daterangepicker.js"></script>
<script src="<?php echo base_url('assets/admin/'); ?>plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
<script src="<?php echo base_url('assets/admin/'); ?>plugins/summernote/summernote-bs4.min.js"></script>
<script src="<?php echo base_url('assets/admin/'); ?>plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
<script src="<?php echo base_url('assets/admin/'); ?>dist/js/adminlte.js"></script>
<script src="<?php echo base_url('assets/admin/'); ?>dist/js/demo.js"></script>
<!-- <script src="<?php echo base_url('assets/admin/'); ?>dist/js/pages/dashboard.js"></script> -->

<script src="<?php echo base_url('assets/admin')?>/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url('assets/admin')?>/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="<?php echo base_url('assets/admin')?>/plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="<?php echo base_url('assets/admin')?>/plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
<script src="<?php echo base_url('assets/admin')?>/plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
<script src="<?php echo base_url('assets/admin')?>/plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<script src="<?php echo base_url('assets/admin')?>/plugins/bs-custom-file-input/bs-custom-file-input.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-lite.min.js"></script>
