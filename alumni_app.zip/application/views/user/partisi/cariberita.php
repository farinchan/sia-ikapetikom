<br>
<form class="d-flex" action="<?php echo base_url('main/beritacari') ?>" method="GET">
    <input class="form-control me-2" type="search" name="search" placeholder="Cari Berita" aria-label="Search"><br>
    <button class="btn btn-outline-info" type="submit">Cari</button>
</form>