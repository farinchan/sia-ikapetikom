<section class="breadcrumbs">
<!-- <div class="container">
    <div class="d-flex justify-content-between align-items-center">
        <ol>
            <li><a href="<?php echo base_url('main'); ?>">Home</a></li>
            <li>Alumni Geographics Information </li>
        </ol>
        <?php $this->load->view('user/partisi/cariberita.php') ?>
    </div>
</div>
</section>
<section class="inner-page"> -->
<div class="container">

    <div id="map" height= "400px"></div>
  
</div>
</section>